﻿using ASBA.BRIDGE;
using System.Collections.Generic;

namespace ASBA.BAL.IRepository
{
    public interface IAdventureWorkRepo    
    {
        List<DimAccountModal> GetDimAccount();
    }
}
