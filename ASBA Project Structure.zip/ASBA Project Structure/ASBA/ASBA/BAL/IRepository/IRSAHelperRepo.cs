﻿namespace ASBA.BAL.IRepository
{
    public interface IRSAHelperRepo
    {
        string Encrypt(string text);
        string Decrypt(string encrypted);
    }
}
