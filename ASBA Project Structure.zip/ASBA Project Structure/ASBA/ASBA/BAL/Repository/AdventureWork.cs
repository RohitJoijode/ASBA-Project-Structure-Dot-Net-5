﻿using ASBA.BRIDGE;
using System.Collections.Generic;
using System;
using System.Linq;

namespace ASBA.BAL.Repository
{
    public class AdventureWork : ASBA.BAL.IRepository.IAdventureWorkRepo
    {
        private readonly DBEngine _DbEngine;
        public AdventureWork(DBEngine DbEngine)
        {
            _DbEngine = DbEngine;
        }

        public List<DimAccountModal> GetDimAccount()
        {
            List<DimAccountModal> DimAccountList = new List<DimAccountModal>();
            try
            {
                DimAccountList = _DbEngine.SqlQuery<DimAccountModal>("GetDimAccount").ToList();
            }
            catch (Exception ex)
            {
                
            }
            return DimAccountList;
        }
    }
}
