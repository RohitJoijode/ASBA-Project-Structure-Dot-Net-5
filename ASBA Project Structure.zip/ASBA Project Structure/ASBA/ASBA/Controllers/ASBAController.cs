﻿using ASBA.BAL.Repository;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using ASBA.BAL.IRepository;
using ASBA.BRIDGE;
using Microsoft.AspNetCore.Http;
using System.IO;
using Microsoft.AspNetCore.Hosting;
using System.Text.Json;

namespace ASBA.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ASBAController : Controller
    {
        private readonly IAdventureWorkRepo _AdventureWorks;
        private readonly DBEngine _DbEngine;

        public ASBAController(IAdventureWorkRepo AdventureWorks,DBEngine DbEngine)
        {
            _AdventureWorks = AdventureWorks;
            _DbEngine = DbEngine;
        }

        [HttpGet,Route("GetDimAccount")]
        public IActionResult GetDimAccount()
        {
            dynamic RequestObject = null,ResponseObject = null,ReturnData = null;
            List<DimAccountModal> DimAccountList = new List<DimAccountModal>();
            try
            {
                DimAccountList = _AdventureWorks.GetDimAccount();
                if (DimAccountList.Count > 0)
                {
                    ReturnData = DimAccountList;
                }
                else
                {
                    ReturnData = JsonSerializer.Serialize("Data not Found !!!!");
                }

            }
            catch (Exception ex)
            {
                
            }
            return Ok(ReturnData);
        }
    }
}
