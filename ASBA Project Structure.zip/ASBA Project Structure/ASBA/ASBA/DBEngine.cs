﻿using ASBA.DAL;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASBA
{
    public class DBEngine : DbContext
    {
        public DBEngine(DbContextOptions<DBEngine> dbContextOptions)
       : base(dbContextOptions)
        {
        }

        public DbSet<DimAccount> DimAccount { get; set; }
    }
}
