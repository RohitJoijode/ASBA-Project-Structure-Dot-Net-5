﻿namespace ASBA.ENUMS
{
    enum Role
    {
        Admin = 1,
        SubAdmin = 2
    }
}
